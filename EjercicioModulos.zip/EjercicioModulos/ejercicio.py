# Importo mi modulo
import operacionesBasicas as opb

def main():

    # Llamo los modulos 
    suma = opb.suma(7,5)
    resta = opb.resta(9,5)
    multiplicacion = opb.multiplicacion(4,4)
    division = opb.division(24,4)

    print(f"La suma es: {suma}")
    print(f"La resta es: {resta}")
    print(f"La multiplicación es: {multiplicacion}")
    print(f"La división es: {division}")

if __name__ == '__main__':
    main()